package com.cg.patmWallet.bean;

import java.math.BigDecimal;

public class Wallet {

	private double balance;

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance2) {
		this.balance = balance2;
	}

	@Override
	public String toString() {
		return "Wallet [balance=" + balance + "]";
	}

}
