package com.cg.lab42.bean;

public class Account {
    boolean withdraw(int x)
    {return true;}
    int balance=1000;
}
