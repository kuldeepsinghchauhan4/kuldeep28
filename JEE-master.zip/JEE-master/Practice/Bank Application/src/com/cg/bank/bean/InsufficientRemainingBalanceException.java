package com.cg.bank.bean;

public class InsufficientRemainingBalanceException extends Exception {
	 InsufficientRemainingBalanceException(String s)
	 {super(s);}
}
