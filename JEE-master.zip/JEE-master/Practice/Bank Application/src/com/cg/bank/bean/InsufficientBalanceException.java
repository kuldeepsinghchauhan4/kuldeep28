package com.cg.bank.bean;

public class InsufficientBalanceException extends Exception {
           InsufficientBalanceException(String s)
           {super(s);}
}
