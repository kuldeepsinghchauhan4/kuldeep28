package com.cg.bank.bean;

public class InvalidAccountNumber extends Exception {
	InvalidAccountNumber(String s)
	{super(s);
	
	}
}
