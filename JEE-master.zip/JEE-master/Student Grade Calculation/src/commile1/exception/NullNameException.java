package commile1.exception;

public class NullNameException extends Exception {
	public NullNameException(String s)
	{super(s);}
}
