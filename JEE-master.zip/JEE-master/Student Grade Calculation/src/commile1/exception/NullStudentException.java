package commile1.exception;

public class NullStudentException extends Exception {
	 public NullStudentException(String s)
	 {super(s);}
}
