package commile1.exception;

public class NullMarksArrayException extends Exception {
	public NullMarksArrayException(String s)
	{super(s);}
}
