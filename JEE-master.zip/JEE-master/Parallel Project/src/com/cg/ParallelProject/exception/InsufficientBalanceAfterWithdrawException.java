package com.cg.ParallelProject.exception;

public class InsufficientBalanceAfterWithdrawException extends Exception {

}
